<?php 
$self = $_SERVER['PHP_SELF'];
if(!strpos($self, "login.php") && !strpos($self, "registration.php")){
    if(!isset($_SESSION['userdata']['id'])){
        redirect('./login.php');
    }
}
?>